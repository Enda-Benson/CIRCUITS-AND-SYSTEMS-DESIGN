
class Pong {
public:

  int Pong_width = 5;
  int Pong_height = 15;
  int Pong_x = 64;  // X Position of the cursor, initialised to the centre of the screen
  int Pong_y = 32;  // Y Position of the cursor, initialised to the centre of the screen

};              // close cursor class
Pong pong;  //initialise an instance of the ball class (initialise a ball)
